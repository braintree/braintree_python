from braintree.modification import Modification

class AddOn(Modification):
    pass
