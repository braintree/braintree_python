from braintree.modification import Modification

class Discount(Modification):
    pass
